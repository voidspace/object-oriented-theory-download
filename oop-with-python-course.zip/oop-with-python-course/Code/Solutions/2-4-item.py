# Extended Item class with class method
class Item:
    __slots__ = ("name", "_amount", "_price")

    def __init__(self, name, amount, price):
        self.name = name
        self.amount = amount
        self.price = price

    def cost(self):
        return self.amount * self.price

    def sell(self, n):
        if n <= self.amount:
            self.amount = n
        else:
            raise ValueError(f"Cannot sell {n} items, only {self.amount} available")

    @classmethod
    def from_row(cls, row):
        """Create an Item from a CSV row (name, amount, price)."""
        name = row[0]
        amount = int(row[1])  # Convert string to integer
        price = float(row[2])  # Convert string to float
        return cls(name, amount, price)

    @property
    def amount(self):
        return self._amount

    @amount.setter
    def amount(self, value):
        if not isinstance(value, int) or value < 0:
            raise TypeError(f"Expected positive int got {value!r}")
        self._amount = value

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, value):
        if not isinstance(value, float) or value < 0:
            raise TypeError(f"Expected positive float got {value!r}")
        self._price = value
