class DataConnection:
    active = True

    def __init__(self, address, port):
        self.socket_address = address, port

    @classmethod
    def toggle(cls):
        cls.active = not cls.active
