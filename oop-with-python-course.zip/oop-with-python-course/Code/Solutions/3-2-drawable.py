from typing import Protocol, runtime_checkable
from dataclasses import dataclass


@runtime_checkable
class Drawable(Protocol):
    """Protocol defining what makes something drawable on our canvas."""

    def get_position(self) -> tuple[int, int]:
        """Return the x, y position of the shape."""
        ...

    def draw(self) -> str:
        """Return a string describing how the shape is drawn."""
        ...


def validate_positive(*args: int) -> None:
    """Validate that all arguments are positive integers."""
    if any(x < 0 for x in args):
        raise ValueError("All dimensions must be positive")


@dataclass
class Circle:
    """A circle that implements the Drawable protocol."""
    x: int
    y: int
    radius: int

    def __post_init__(self):
        """Validate coordinates and dimensions after initialization."""
        validate_positive(self.x, self.y, self.radius)

    def get_position(self) -> tuple[int, int]:
        """Return the circle's position."""
        return (self.x, self.y)

    def draw(self) -> str:
        """Return a string describing the circle being drawn."""
        return f"Drawing circle at ({self.x}, {self.y}) with radius {self.radius}"


@dataclass
class Rectangle:
    """A rectangle that implements the Drawable protocol."""
    x: int
    y: int
    width: int
    height: int

    def __post_init__(self):
        """Validate coordinates and dimensions after initialization."""
        validate_positive(self.x, self.y, self.width, self.height)

    def get_position(self) -> tuple[int, int]:
        """Return the rectangle's position."""
        return (self.x, self.y)

    def draw(self) -> str:
        """Return a string describing the rectangle being drawn."""
        return f"Drawing rectangle at ({self.x}, {self.y}) of size {self.width}x{self.height}"


class Triangle:
    """A shape that doesn't fully implement the Drawable protocol."""

    def get_position(self) -> tuple[int, int]:
        """Return the triangle's position."""
        return (0, 0)
    # Intentionally missing draw() method to demonstrate protocol checking


class Canvas:
    """A canvas that can contain and draw shapes implementing the Drawable protocol."""

    def __init__(self):
        """Initialize an empty canvas."""
        self.shapes: list[Drawable] = []

    def add_shape(self, shape: Drawable) -> None:
        """
        Add a shape to the canvas.

        Args:
            shape: Any object implementing the Drawable protocol

        Raises:
            TypeError: If the shape doesn't implement Drawable
        """
        if not isinstance(shape, Drawable):
            raise TypeError("Can only add drawable shapes to canvas")
        self.shapes.append(shape)
        print(f"Added {shape.__class__.__name__.lower()} at {shape.get_position()}")

    def draw_all(self) -> None:
        """Draw all shapes on the canvas in the order they were added."""
        for shape in self.shapes:
            print(shape.draw())


def main():
    """Example usage demonstrating all features."""
    # Create shapes
    try:
        circle = Circle(x=100, y=100, radius=50)
        rectangle = Rectangle(x=200, y=200, width=40, height=60)
        canvas = Canvas()

        # Demonstrate protocol checking
        print(f"Circle implements Drawable: {isinstance(circle, Drawable)}")
        print(f"Rectangle implements Drawable: {isinstance(rectangle, Drawable)}")

        # Add and draw shapes
        canvas.add_shape(circle)
        canvas.add_shape(rectangle)
        print("\nDrawing all shapes:")
        canvas.draw_all()

        # Demonstrate error handling
        print("\nTrying to add invalid shapes:")
        triangle = Triangle()
        canvas.add_shape(triangle)  # Should raise TypeError

    except (TypeError, ValueError) as e:
        print(f"Error: {e}")

    # Demonstrate validation
    print("\nTrying to create invalid shapes:")
    try:
        invalid_circle = Circle(x=-10, y=100, radius=50)
    except ValueError as e:
        print(f"Error creating circle: {e}")

    try:
        invalid_rectangle = Rectangle(x=0, y=0, width=-40, height=60)
    except ValueError as e:
        print(f"Error creating rectangle: {e}")


if __name__ == "__main__":
    main()
