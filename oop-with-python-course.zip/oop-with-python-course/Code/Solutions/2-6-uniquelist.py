class UniqueList:
    def __init__(self):
        self.items = []

    def __getitem__(self, index):
        return self.items[index]

    def __setitem__(self, index, value):
        if value not in self.items:
            self.items[index] = value

    def __delitem__(self, index):
        del self.items[index]

    def __contains__(self, value):
        return value in self.items

    def __len__(self):
        return len(self.items)

    def __iter__(self):
        for item in self.items:
            yield item

    def __repr__(self):
        return f'{self.__class__.__name__}({self.items!r})'

    def insert(self, index, value):
        if value not in self.items:
            self.items.insert(index, value)

    def append(self, value):
        if value not in self.items:
            self.items.append(value)
