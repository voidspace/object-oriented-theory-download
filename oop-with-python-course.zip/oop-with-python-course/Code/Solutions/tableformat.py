# tableformat.py


class TableFormatter:
    def report(self, headers, rows):
        self.headings(headers)
        for row in rows:
            self.row(row)

    def headings(self, headers):
        raise NotImplementedError()

    def row(self, rowdata):
        raise NotImplementedError()


class TextTableFormatter(TableFormatter):
    def headings(self, headers):
        print(" ".join(f"{h:>10s}" for h in headers))
        print(("-" * 10 + " ") * len(headers))

    def row(self, rowdata):
        print(" ".join(f"{r:>10s}" for r in rowdata))


class CSVTableFormatter(TableFormatter):
    """
    Output portfolio data in CSV format.
    """

    def headings(self, headers):
        print(",".join(headers))

    def row(self, rowdata):
        print(",".join(rowdata))


class HTMLTableFormatter(TableFormatter):
    def headings(self, headers):
        print("<tr>", end=" ")
        for h in headers:
            print("<th>%s</th>" % h, end=" ")
        print("</tr>")

    def row(self, rowdata):
        print("<tr>", end=" ")
        for d in rowdata:
            print("<td>%s</td>" % d, end=" ")
        print("</tr>")


def create_formatter(name):
    """
    Create an appropriate formatter given an output format name
    """
    if name == "txt":
        return TextTableFormatter()
    elif name == "csv":
        return CSVTableFormatter()
    elif name == "html":
        return HTMLTableFormatter()
    else:
        raise RuntimeError(f"Unknown table format {name}")
