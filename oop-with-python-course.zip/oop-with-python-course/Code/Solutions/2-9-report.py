# report.py

import csv
import stock
import tableformat


def read_portfolio(filename: str) -> list[stock.Stock]:
    portfolio = []
    with open(filename) as f:
        rows = csv.reader(f)
        headers = next(rows)
        for row in rows:
            item = stock.Stock.from_row(row)
            portfolio.append(item)
    return portfolio


def print_report(portfolio: list[stock.Stock], formatter: tableformat.TableFormatter) -> None:
    '''
    Print a nicely formated table from a list of Stock objects.
    '''
    formatter.headings(['Name', 'Shares', 'Price'])
    for stock in portfolio:
        rowdata = [stock.name, str(stock.shares), f'{stock.price:0.2f}']
        formatter.row(rowdata)


def create_formatter(name: str) -> tableformat.TableFormatter:
    '''
    Create an appropriate formatter given an output format name
    '''
    if name == 'txt':
        return tableformat.TextTableFormatter()
    elif name == 'csv':
        return tableformat.CSVTableFormatter()
    elif name == 'html':
        return tableformat.HTMLTableFormatter()
    else:
        raise RuntimeError(f'Unknown table format {name}')


def portfolio_report(portfoliofile: str, fmt: str) -> None:
    '''
    Make a stock report given portfolio and price data files.
    '''
    # Read data files
    portfolio = read_portfolio(portfoliofile)

    # Print it out
    formatter = create_formatter(fmt)
    print_report(portfolio, formatter)


def main(args: list[str]) -> None:
    fmt = 'txt'
    if len(args) == 2:
        filename = args[1]
    elif len(args) == 3:
        filename = args[1]
        fmt = args[2]
    elif len(args) > 3:
        raise SystemExit(f'Usage {args[0]} portfile format')
    else:
        # filename = input('Porfolio filename:')
        filename = 'Data/portfolio.csv'

    portfolio_report(filename, fmt)

if __name__ == '__main__':
    import sys
    main(sys.argv)
