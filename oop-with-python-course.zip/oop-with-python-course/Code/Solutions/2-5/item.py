import csv
from tableformat import create_formatter


# Extended Item class with class method
class Item:
    def __init__(self, name, amount, price):
        self.name = name
        self.amount = amount
        self.price = price

    def cost(self):
        return self.amount * self.price

    def sell(self, n):
        if n <= self.amount:
            self.amount -= n
        else:
            raise ValueError(f"Cannot sell {n} items, only {self.amount} available")

    @classmethod
    def from_row(cls, row):
        """Create an Item from a CSV row (name, amount, price)."""
        name = row[0]
        amount = int(row[1])  # Convert string to integer
        price = float(row[2])  # Convert string to float
        return cls(name, amount, price)

    @property
    def amount(self):
        return self._amount

    @amount.setter
    def amount(self, value):
        if not isinstance(value, int) or value < 0:
            raise TypeError(f"Expected positive int got {value!r}")
        self._amount = value

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, value):
        if not isinstance(value, float) or value < 0:
            raise TypeError(f"Expected positive float got {value!r}")
        self._price = value


class Inventory:
    def __init__(self):
        self.items = {}

    def add_item(self, item):
        self.items[item.name] = item

    def remove_item(self, item_name):
        if item_name in self.items:
            del self.items[item_name]
        else:
            raise ValueError(f"Item '{item_name}' not found in inventory")

    def get_total_value(self):
        return sum(item.cost() for item in self.items.values())

    def display_inventory(self, formatter=None):
        if formatter is None:
            formatter = create_formatter("txt")

        headers = ["Name", "Amount", "Price", "Value"]
        rowdata = [
            (item.name, f"{item.amount}", f"{item.price:.2f}", f"{item.cost():.2f}")
            for item in self.items.values()
        ]
        formatter.report(headers, rowdata)

    def restock(self, item_name, amount):
        if item_name in self.items:
            self.items[item_name].amount += amount
        else:
            raise ValueError(f"Item '{item_name}' not found in inventory")

    @classmethod
    def from_csv(cls, filename):
        """Create an Inventory from a CSV file."""
        inventory = cls()  # instantiate an inventory

        with open(filename) as f:
            rows = csv.reader(f)
            headers = next(rows)  # Skip the header row
            for row in rows:
                item = Item.from_row(row)  # Create Item using class method
                inventory.add_item(item)  # Add to inventory

        return inventory


# Example usage:
if __name__ == "__main__":
    # Pick a report format
    fmt = "html"

    # Create test CSV file
    with open("inventory.csv", "w") as f:
        f.write("name,amount,price\n")
        f.write("bike,100,490.10\n")
        f.write("table,50,91.50\n")
        f.write("chair,200,45.99\n")

    # Test loading from CSV
    inventory = Inventory.from_csv("inventory.csv")

    # Create a formatter and use it to create the report
    formatter = create_formatter(fmt)
    inventory.display_inventory(formatter)
