# report.py

import csv
import stock


def read_portfolio(filename: str) -> list[stock.Stock]:
    portfolio = []
    with open(filename) as f:
        rows = csv.reader(f)
        headers = next(rows)
        for row in rows:
            item = stock.Stock.from_row(row)
            portfolio.append(item)
    return portfolio


def print_report(portfolio):
    '''
    Print a nicely formated table from a list of Stock objects.
    '''
    headers = ('Name', 'Shares', 'Price')
    for header in headers:
        print(f'{header:>10s}', end=' ')
    print()
    print(('-' * 10 + ' ') * len(headers))
    for stock in portfolio:
        price_string = f"${stock.price:.2f}"
        print(f'{stock.name:>10s} {stock.shares:>10d} {price_string:>10s}')


def portfolio_report(portfoliofile):
    '''
    Make a stock report given portfolio and price data files.
    '''
    # Read data files
    portfolio = read_portfolio(portfoliofile)

    # Print it out
    print_report(portfolio)


def main(args):
    if len(args) == 2:
        filename = args[1]
    elif len(args) > 2:
        raise SystemExit(f'Usage {args[0]} portfile')
    else:
        # filename = input('Porfolio filename:')
        filename = 'Data/portfolio.csv'

    portfolio_report(filename)

if __name__ == '__main__':
    import sys
    main(sys.argv)
