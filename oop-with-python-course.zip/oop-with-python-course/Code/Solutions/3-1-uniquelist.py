from collections.abc import Iterator, MutableSequence
from typing import Any


class UniqueList(MutableSequence):
    def __init__(self, iterable=None):
        self._items = []
        if iterable is not None:
            self.extend(iterable)

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, index):
        return self._items[index]

    def __iter__(self) -> Iterator:
        return iter(self._items)

    def __delitem__(self, idx: int | slice) -> None:
        del self._items[idx]

    def insert(self, index: int, item: Any) -> None:
        if item not in self._items:
            self._items.insert(index, item)

    def __eq__(self, other) -> bool:
        if isinstance(other, (UniqueList, list)):
            return self._items == other
        return NotImplemented

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self._items})"
