from collections import namedtuple


BaseStock = namedtuple('Stock', ['name', 'shares', 'price'])

class Stock(BaseStock):
    def cost(self):
        return self.shares * self.price

    def sell(self, nshares):
        self.shares -= nshares


from typing import NamedTuple

class Stock(NamedTuple):
    name: str
    shares: int
    price: float

    def cost(self):
        return self.shares * self.price

    def sell(self, nshares):
        self.shares -= nshares


from dataclasses import dataclass

@dataclass(frozen=True)
class Stock:
    name: str
    shares: int
    price: float

    def cost(self):
        return self.shares * self.price

    def sell(self, nshares):
        self.shares -= nshares
