from collections import namedtuple
from dataclasses import dataclass
from typing import NamedTuple


BaseItem = namedtuple("BaseItem", ["name", "amount", "price"])


class Item1(BaseItem):
    def cost(self):
        return self.amount * self.price

    def sell(self, n):
        self.amount -= n


class Item2(NamedTuple):
    name: str
    shares: int
    price: float

    def cost(self):
        return self.amount * self.price

    def sell(self, n):
        self.amount -= n


@dataclass(frozen=True)
class Item3:
    name: str
    amount: int
    price: float

    def cost(self):
        return self.amount * self.price

    def sell(self, n):
        self.amount -= n
