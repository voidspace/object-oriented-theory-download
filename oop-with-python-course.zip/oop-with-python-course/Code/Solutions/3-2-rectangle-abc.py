from abc import ABC, abstractmethod


class Shape(ABC):
    @abstractmethod
    def area(self):
        """Calculate the area of the shape."""

    @abstractmethod
    def perimeter(self):
        """Calculate the perimeter of the shape."""


class Rectangle:
    def __init__(self, width, height):
        self.width = width
        self.height = height
    def area(self):
        return self.width * self.height
    def perimeter(self):
        return 2 * (self.width + self.height)

Shape.register(Rectangle)

r = Rectangle(4, 10)
assert isinstance(r, Rectangle)
