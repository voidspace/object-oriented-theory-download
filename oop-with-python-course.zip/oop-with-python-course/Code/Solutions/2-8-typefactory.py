class _Item:
    def __init__(self, name, amount, price):
        self.name = name
        self.amount = amount
        self.price = price

    def cost(self):
        return self.amount * self.price

    def sell(self, n):
        self.shares -= n


def make_stock_class(factor=1.0):
    def cost(self):
        return super(Item, self).cost() * factor

    Item = type("Item", (_Item,), {"cost": cost})
    return Item
