class _Stock:
    def __init__(self, name, shares, price):
        self.name = name
        self.shares = shares
        self.price = price

    def cost(self):
        return self.shares * self.price

    def sell(self, nshares):
        self.shares -= nshares


def make_stock_class(factor=1.0):
    def cost(self):
        return super(Stock, self).cost() * factor
    Stock = type('Stock', (_Stock,), {'cost': cost})
    return Stock
