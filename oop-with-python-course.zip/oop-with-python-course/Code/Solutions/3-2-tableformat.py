# tableformat.py
import typing

@typing.runtime_checkable
class TableFormatter(typing.Protocol):
    def headings(self, headers: list[str]) -> None:
        raise NotImplementedError()

    def row(self, rowdata: list[str]) -> None:
        raise NotImplementedError()


class TextTableFormatter:
    def headings(self, headers: list[str]) -> None:
        print(' '.join('%10s' % h for h in headers))
        print(('-' * 10 + ' ') * len(headers))

    def row(self, rowdata: list[str]) -> None:
        print(' '.join('%10s' % d for d in rowdata))


class CSVTableFormatter:
    '''
    Output portfolio data in CSV format.
    '''
    def headings(self, headers):
        print(','.join(headers))

    def row(self, rowdata):
        print(','.join(rowdata))


class HTMLTableFormatter:
    def headings(self, headers: list[str]) -> None:
        print('<tr>', end=' ')
        for h in headers:
            print('<th>%s</th>' % h, end=' ')
        print('</tr>')

    def row(self, rowdata: list[str]) -> None:
        print('<tr>', end=' ')
        for d in rowdata:
            print('<td>%s</td>' % d, end=' ')
        print('</tr>')

def create_formatter(name: str) -> TableFormatter:
    '''
    Create an appropriate formatter given an output format name
    '''
    if name == 'txt':
        return TextTableFormatter()
    elif name == 'csv':
        return CSVTableFormatter()
    elif name == 'html':
        return HTMLTableFormatter()
    else:
        raise RuntimeError(f'Unknown table format {name}')

