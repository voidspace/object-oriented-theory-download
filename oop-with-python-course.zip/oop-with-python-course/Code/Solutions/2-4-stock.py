import csv


class Stock:

    def __init__(self, name, shares, price):
        self.name = name
        self.shares = shares
        self.price = price

    @property
    def shares(self):
        return self._shares

    @shares.setter
    def shares(self, value):
        if not isinstance(value, int) or value < 0:
            raise TypeError(f'Expected positive int got {value!r}')
        self._shares = value

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, value):
        if not isinstance(value, float) or value < 0:
            raise TypeError(f'Expected positive float got {value!r}')
        self._price = value

    def cost(self):
        return self.shares * self.price

    def sell(self, nshares):
        self.shares -= nshares

    @classmethod
    def from_row(cls, row):
        name = row[0]
        shares = int(row[1])
        price = float(row[2])
        return cls(name, shares, price)


def read_portfolio(filename: str) -> list[Stock]:
    portfolio = []
    with open(filename) as f:
        rows = csv.reader(f)
        headers = next(rows)
        for row in rows:
            stock = Stock.from_row(row)
            portfolio.append(stock)
    return portfolio


if __name__ == '__main__':
    filename = 'Data/portfolio.csv'
    read_portfolio(filename)
