# Solution for item.py (Exercise 2-2)
class Item:
    def __init__(self, name, amount, price):
        """Initialize an Item with name, amount, and price."""
        self.name = name
        self.amount = amount
        self.price = price

    def cost(self):
        """Calculate the total cost of the items."""
        return self.amount * self.price

    def sell(self, n):
        """Sell n items by reducing the amount."""
        if n <= self.amount:
            self.amount -= n
        else:
            raise ValueError(f"Cannot sell {n} items, only {self.amount} available")


# Solution for inventory.py (Exercise 2-3)
class Inventory:
    def __init__(self):
        """Initialize an empty inventory."""
        self.items = {}  # Dictionary to store items with name as key

    def add_item(self, item):
        """Add an Item object to the inventory."""
        self.items[item.name] = item

    def remove_item(self, item_name):
        """Remove an item from the inventory by name."""
        if item_name in self.items:
            del self.items[item_name]
        else:
            raise ValueError(f"Item '{item_name}' not found in inventory")

    def get_total_value(self):
        """Calculate the total value of all items in inventory."""
        return sum(item.cost() for item in self.items.values())

    def display_inventory(self):
        """Display a formatted table of all items in inventory."""
        print("      Name     Amount      Price      Value")
        print("----------------------------------------")

        for item in self.items.values():
            value = item.cost()
            print(
                f"{item.name:>10s} {item.amount:>10d} {item.price:>10.2f} {value:>10.2f}"
            )

    def restock(self, item_name, amount):
        """Increase the amount of an existing item in inventory."""
        if item_name in self.items:
            self.items[item_name].amount += amount
        else:
            raise ValueError(f"Item '{item_name}' not found in inventory")


# Example usage and testing:
if __name__ == "__main__":
    # Test Item class
    bike = Item("bike", 100, 490.10)
    print(f"Bike cost: {bike.cost()}")
    bike.sell(25)
    print(f"Remaining bikes: {bike.amount}")

    # Test Inventory class
    warehouse = Inventory()
    bike = Item("bike", 100, 490.10)
    table = Item("table", 50, 91.5)

    warehouse.add_item(bike)
    warehouse.add_item(table)

    print("\nInitial inventory:")
    warehouse.display_inventory()

    print("\nRestocking tables:")
    warehouse.restock("table", 25)
    warehouse.display_inventory()

    print("\nRemoving bikes:")
    warehouse.remove_item("bike")
    warehouse.display_inventory()
