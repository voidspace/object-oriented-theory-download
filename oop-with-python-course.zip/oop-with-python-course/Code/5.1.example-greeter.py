class Greeter:
    def __init__(self, language):
        self.greeting = {
        "en": "Hello", "es": "Hola",
        "fr": "Bonjour", "de": "Hallo",
        "it": "Ciao", "pt": "Olá",
        "nl": "Hallo"}[language]

    def greet(self, name):
        print(f'{self.greeting} {name}')

def greeter(language):
    greeting = {
        "en": "Hello", "es": "Hola",
        "fr": "Bonjour", "de": "Hallo",
        "it": "Ciao", "pt": "Olá",
        "nl": "Hallo"}[language]
    def greet(name):
        print(f'{greeting} {name}')
    return greet