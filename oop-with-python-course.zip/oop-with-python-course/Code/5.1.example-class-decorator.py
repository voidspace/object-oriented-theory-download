def logged_getattr(cls):
    # Get the original implementation
    orig_getattribute = cls.__getattribute__

    # Replacement method
    def __getattribute__(self, name):
        print("Getting:", name)
        return orig_getattribute(self, name)

    # Attach to the class
    cls.__getattribute__ = __getattribute__
    return cls


@logged_getattr
class Spam:
    def foo(self):
        pass

    def bar(self):
        pass
