import types

def __new__(cls):
    raise NotImplementedError

class Meta(type):
    def __new__(cls, name, bases, body):
        body['__new__'] = __new__
        for name, obj in list(body.items()):
            if name == '__new__':
                continue
            if isinstance(obj, types.FunctionType):
                body[name] = classmethod(obj)
        new_cls = super().__new__(cls, name, (object,), body)
        new_cls.__init__()
        return new_cls

class Base(metaclass=Meta):
    def __init__(self):
        pass


class Thing(Base):
    def __init__(self):
        self.x = 3
    def foo(self):
        print(self.x)
