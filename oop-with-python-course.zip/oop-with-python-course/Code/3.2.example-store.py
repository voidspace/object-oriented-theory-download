import typing
from dataclasses import dataclass

@dataclass
class Item:
    id: int

@typing.runtime_checkable
class AbstractStore(typing.Protocol):
    def get(self, id: int) -> Item:
        """Fetch an item by id"""
    def set(self, item: Item) -> None:
        """Store an item"""

class Store:
    store: dict[int, Item]
    def __init__(self):
        self.store = {}
    def get(self, id: int) -> Item:
        return self.store[id]
    def set(self, item: Item) -> None:
        self.store[item.id] = item

class Shop:
    _store: AbstractStore

    def __init__(self):
        self._store = Store()

assert isinstance(Store(), AbstractStore)
