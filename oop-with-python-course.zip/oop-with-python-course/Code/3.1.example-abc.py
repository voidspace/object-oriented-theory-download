from abc import ABCMeta, abstractmethod


class Shape(metaclass=ABCMeta):
    @abstractmethod
    def area(self):
        """Calculate the area of the shape."""

    @abstractmethod
    def perimeter(self):
        """Calculate the perimeter of the shape."""


# Example implementation of Shape: Rectangle
class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def area(self):
        return self.width * self.height

    def perimeter(self):
        return 2 * (self.width + self.height)


## An alternative to Rectangle explicitly subclassing Shape
# Shape.register(Rectangle)
