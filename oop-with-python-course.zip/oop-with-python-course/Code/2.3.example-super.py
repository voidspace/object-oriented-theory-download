class Parent:
    def method(self):
        print("Parent")


class A(Parent):
    def method(self):
        print("A")
        super().method()


class B(Parent):
    def method(self):
        print("B")
        super().method()


class C(A, B):
    pass


C().method()
