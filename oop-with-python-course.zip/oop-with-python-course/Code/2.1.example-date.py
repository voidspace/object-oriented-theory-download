class Date:

    datefmt = '{year}-{month}-{day}'

    def __init__(self, year, month, day):
        self.year = year
        self.month = month
        self.day = day

    def __str__(self):
        return self.datefmt.format(year=self.year,
                                   month=self.month,
                                   day=self.day)

class USDate(Date):
    datefmt = '{month}/{day}/{year}'
