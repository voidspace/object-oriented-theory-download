class Dog:
    def noise(self):
        return 'Woof'
    def chase(self):
        return 'Chasing!'


class Bike:
    def noise(self):
        return 'Ding!'
    def pedal(self):
        return 'Pedaling!'


class Loud:
    def noise(self):
        return super().noise().upper()


class LoudDog(Loud, Dog):
    pass


class LoudBike(Loud, Bike):
    pass