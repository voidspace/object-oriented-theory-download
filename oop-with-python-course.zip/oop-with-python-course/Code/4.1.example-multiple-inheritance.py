class A: pass
class B: pass
class C(A, B): pass
class D(B): pass
class E(C, D): pass

print(E.__mro__)